-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 14 oct. 2019 à 16:29
-- Version du serveur :  5.7.26
-- Version de PHP :  5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `animaux`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prénom` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `mot de passe` varchar(100) NOT NULL,
  `num tel` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `adoption`
--

DROP TABLE IF EXISTS `adoption`;
CREATE TABLE IF NOT EXISTS `adoption` (
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  `nom_animal` varchar(100) NOT NULL,
  `race` varchar(100) NOT NULL,
  `sexe` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `id_annonceur` int(11) NOT NULL,
  `nom_annonceur` varchar(100) NOT NULL,
  `prénom_annonceur` varchar(100) NOT NULL,
  `num_tel` int(11) NOT NULL,
  `mail` varchar(200) NOT NULL,
  `état` varchar(50) NOT NULL,
  PRIMARY KEY (`ref`),
  KEY `id_annonceur` (`id_annonceur`),
  KEY `id_annonceur_2` (`id_annonceur`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `annonce`
--

DROP TABLE IF EXISTS `annonce`;
CREATE TABLE IF NOT EXISTS `annonce` (
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  `nom_animal` varchar(100) NOT NULL,
  `race` varchar(100) NOT NULL,
  `sexe` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `prix` float NOT NULL,
  `description` varchar(1500) NOT NULL,
  `id_vendeur` int(11) NOT NULL,
  `nom_vendeur` varchar(100) NOT NULL,
  `prénom_vendeur` varchar(100) NOT NULL,
  `num_tel` int(11) NOT NULL,
  `mail` varchar(200) NOT NULL,
  `état` varchar(100) NOT NULL,
  PRIMARY KEY (`ref`),
  KEY `fk_ann_client` (`id_vendeur`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prénom` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `mot de passe` varchar(100) NOT NULL,
  `num tel` int(11) NOT NULL,
  `sexe` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `coiffeurs`
--

DROP TABLE IF EXISTS `coiffeurs`;
CREATE TABLE IF NOT EXISTS `coiffeurs` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prénom` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `mot de passe` varchar(100) NOT NULL,
  `spécialité` varchar(100) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `num tel` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `offres`
--

DROP TABLE IF EXISTS `offres`;
CREATE TABLE IF NOT EXISTS `offres` (
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `date début` date NOT NULL,
  `date fin` date NOT NULL,
  `prix` float NOT NULL,
  `id_coiffeur` int(11) NOT NULL,
  `nom_coiffeur` varchar(100) NOT NULL,
  PRIMARY KEY (`ref`),
  KEY `fk_offres_coiffeur` (`id_coiffeur`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

DROP TABLE IF EXISTS `produits`;
CREATE TABLE IF NOT EXISTS `produits` (
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `nom` text NOT NULL,
  `marque` varchar(100) NOT NULL,
  `prix` float NOT NULL,
  `description` varchar(100) NOT NULL,
  `quantité` int(11) NOT NULL,
  `adresse_boutique` varchar(100) NOT NULL,
  `nom_boutique` varchar(100) NOT NULL,
  `num_tel` int(11) NOT NULL,
  `état` varchar(100) NOT NULL,
  PRIMARY KEY (`ref`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `rdv`
--

DROP TABLE IF EXISTS `rdv`;
CREATE TABLE IF NOT EXISTS `rdv` (
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prénom` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `heur` time NOT NULL,
  `service` varchar(100) NOT NULL,
  `nom_coiffeur` varchar(100) NOT NULL,
  `id_coiffeur` int(11) NOT NULL,
  PRIMARY KEY (`ref`),
  KEY `fk_etud_etudiants` (`id_client`),
  KEY `fk_etud_etu` (`id_coiffeur`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sos`
--

DROP TABLE IF EXISTS `sos`;
CREATE TABLE IF NOT EXISTS `sos` (
  `ref` int(11) NOT NULL,
  `nom_animal` varchar(100) NOT NULL,
  `race` varchar(100) NOT NULL,
  `sexe` int(11) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `date_de_perte` date NOT NULL,
  `lieu` varchar(100) NOT NULL,
  `id_propriétaire` int(11) NOT NULL,
  `nom_propriétaire` varchar(100) NOT NULL,
  `prénom_propriétaire` varchar(100) NOT NULL,
  `num_tel` int(11) NOT NULL,
  `mail` varchar(200) NOT NULL,
  PRIMARY KEY (`ref`),
  KEY `fk_sos` (`id_propriétaire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `vétérinaire`
--

DROP TABLE IF EXISTS `vétérinaire`;
CREATE TABLE IF NOT EXISTS `vétérinaire` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prénom` varchar(100) NOT NULL,
  `adresse` varchar(200) NOT NULL,
  `num_tel` int(11) NOT NULL,
  `mail` varchar(200) NOT NULL,
  `spécialité` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `événements`
--

DROP TABLE IF EXISTS `événements`;
CREATE TABLE IF NOT EXISTS `événements` (
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `date_début` date NOT NULL,
  `date_fin` date NOT NULL,
  `lieu` varchar(100) NOT NULL,
  `organisateur` varchar(100) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `nombre_de_participants` int(11) NOT NULL,
  PRIMARY KEY (`ref`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
